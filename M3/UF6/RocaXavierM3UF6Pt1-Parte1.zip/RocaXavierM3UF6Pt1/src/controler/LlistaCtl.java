/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controler;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Set;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import model.*;
import persist.*;
import view.*;

/**
 *
 * @author usuari
 */
public class LlistaCtl {
    
    private VistaPrincipal vPrin;
    
    public LlistaCtl() throws SQLException {
       // this.pan = new Pantalla(this);
        this.vPrin = new VistaPrincipal(this);
        this.vPrin.setCategoriaCombo();
        this.vPrin.setTable();
        this.vPrin.setVisible(true);
    }
    
    public TableModel getVaixellsDataTable(String cat, int ordre) throws SQLException {
        
        VaixellDAO vDao = new VaixellDAO();
        
        DefaultTableModel tm = new DefaultTableModel();
        tm.addColumn("Codi");
        tm.addColumn("Nom");
        tm.addColumn("Categoria");
        tm.addColumn("Rating");
        tm.addColumn("Club");
        tm.addColumn("Tipus");
        tm.addColumn("Senior");
        tm.addColumn("Temps");
        tm.addColumn("Temps Compensat");
        ArrayList<Vaixell> vaixells = vDao.getVaixellFiltratPerCategoriaYOrdenat(cat, ordre);      
        for (Vaixell vai : vaixells) {
            Object[] fila = new Object[9]; // Hay tres columnas en la tabla
            // Se rellena cada posición del array con una atributo de Alumne.
            fila[0] = vai.getCodi();
            fila[1] = vai.getNom();  
            fila[2] = vai.getCategoria();  
            fila[3] = vai.getRating();  
            fila[4] = vai.getClub();
            fila[5] = vai.getTipus();
            fila[6] = vai.isSenior(); 
            fila[7] = vai.getTemps();
            fila[8] = vai.getRating() * vai.getTemps();
            // fila[8] = ratin * temps 
            // Se añade al modelo la fila completa.     
            tm.addRow(fila);
        }
        return tm;
    }
   
    public DefaultComboBoxModel getCategorias() {

        CategoriaDAO catDao = new CategoriaDAO();
        DefaultComboBoxModel categorias = new DefaultComboBoxModel();
        ArrayList<Categoria> catArr = null;
        
        try {
            catArr = catDao.getCategoriaList();
  
        } catch (Exception e) {
            System.out.println(e.toString());
        }
        categorias.addElement("...");
        for (Categoria cat : catArr) {
            categorias.addElement(cat.getNom());
        }

        return categorias;
    }
     
    public void mostraVistaAf(){
        BmCtl bmctl = new BmCtl();
        VistaAfegirYModificar vam = new VistaAfegirYModificar(vPrin, true, bmctl);
        vam.setCategoriaCombo(getCategorias());
        bmctl.setVam(vam);
    }
    public void mostraVistaMod(){
        BmCtl bmctl = new BmCtl();
        VistaAfegirYModificar vam = new VistaAfegirYModificar(vPrin, true, bmctl);
        vam.setCategoriaCombo(getCategorias());
        vam.desabilitarCodi();
        bmctl.setVam(vam);
     
    }
    
    public void eliminarVaixell(int codi) throws SQLException{
        VaixellDAO vDao = new VaixellDAO();
        vDao.delete(codi);
    }
    
    public void getVaixell(){
        
    }
   
}
