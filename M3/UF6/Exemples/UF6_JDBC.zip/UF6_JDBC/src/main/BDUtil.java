
package main;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class BDUtil {
 public static void createEstructuraMysql(Connection conn) throws SQLException {
         
        String query = "CREATE TABLE Directores (ID int , Nombre VARCHAR(20), Precio int,primary key(ID))";
                
        PreparedStatement stmt = conn.prepareStatement(query);
        stmt.executeUpdate();
        stmt.close();
       


        
        
         query = "CREATE TABLE Peliculas_directores (pelicula_id int , director_id int\n" +
",FOREIGN KEY (pelicula_id) References Peliculas(ID), FOREIGN KEY (director_id) References Directores(ID));";

        stmt = conn.prepareStatement(query);
        stmt.executeUpdate();
        stmt.close();


       
    }

    public static void netejaTaules(Connection conn) {
        PreparedStatement stmt;
        try {
            String query = "delete from PROPIETARIOS";
            stmt = conn.prepareStatement(query);
            stmt.executeUpdate();
            stmt = conn.prepareStatement("delete from COCHES");
            stmt.executeUpdate();
            stmt.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
   
    
}
