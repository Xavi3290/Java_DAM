/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.text.SimpleDateFormat;
import java.sql.Date;
import java.text.ParseException;
import static main.Ex1.ifExists;

/**
 *
 * @author agustincintas
 */
public class Ex2 {

    static final String driver = "com.mysql.cj.jdbc.Driver";
    static final String url = "jdbc:mysql://localhost:3306/Cine";
    //Nom de la nostra BBDD
    static final String userName = "agustin";
    static final String password = "Adminroot95";
    private static Connection conn = null;

    public static void main(String[] args) throws ParseException {
        // TODO code application logic here

        try {

            Class.forName(driver);
            conn = DriverManager.getConnection(url, userName, password);

//              BDUtil.createEstructuraMysql(conn);
          //  mostraPelis();
  // insertaPelis(4,"Titanic",dameFecha("06/09/2000"),180);
            // insertaDirector(2,"Tim Burton");
           // insertaPeliDirector(4,4);
       //      nomDirector(2);
           //   esborrarPeli(4);
//          insertaPeliDirector(2,3);
//          insertaPeliDirector(2,4);

        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    public static void mostraPelis() throws SQLException, ClassNotFoundException {

        PreparedStatement stm;
        ResultSet result;
        String query = "SELECT * FROM Peliculas order by ID asc";
        stm = conn.prepareStatement(query);
        result = stm.executeQuery();

        while (result.next()) {
            System.out.println("ID: " + result.getInt("ID"));
            System.out.println("Titulo: " + result.getString("Titulo"));
            System.out.println("FechaEstreno: " + result.getDate("FechaEstreno"));
            System.out.println("Duracion: " + result.getInt("Duracion"));
            System.out.println();
        }
        result.close();
        stm.close();
    }

    public static void insertaPelis(int id, String title, Date fecha, int dura) throws SQLException {

        PreparedStatement stm;

        String query = "INSERT INTO Peliculas(ID,Titulo,FechaEstreno,Duracion) values (?,?,?,?)";

        stm = conn.prepareStatement(query);
        stm.setInt(1, id);
        stm.setString(2, title);
        stm.setDate(3, fecha);
        stm.setInt(4, dura);

        int cont = stm.executeUpdate();

        System.out.println("Inserted peli count: " + cont);
        stm.close();

    }

    public static void insertaDirector(int id, String name) throws SQLException {

        PreparedStatement stm;

        String query = "INSERT INTO Directores(ID,Nombre) values (?,?)";

        stm = conn.prepareStatement(query);
        stm.setInt(1, id);
        stm.setString(2, name);

        int cont = stm.executeUpdate();

        System.out.println("Inserted director count: " + cont);
        stm.close();

    }

    public static Date dameFecha(String txt) throws ParseException {
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        String xfecha = txt;

        Date data;
        java.util.Date ndata = formato.parse(xfecha);

        data = new java.sql.Date(ndata.getTime());
        return data;

    }

    public static void insertaPeliDirector(int peliid, int director_id) throws SQLException {

        PreparedStatement stm;

        String query = "INSERT INTO Peliculas_directores values(?,?)";
        stm = conn.prepareStatement(query);
        stm.setInt(1, peliid);
        stm.setInt(2, director_id);

        int cont = stm.executeUpdate();

        System.out.println("Inserted peli_director count: " + cont);
        stm.close();

    }

    public static void nomDirector(int idPeli) throws SQLException {

        PreparedStatement stm;
        ResultSet rs;
        String query = "SELECT d.Nombre FROM Cine.Peliculas_directores pd\n"
                + "inner join Cine.Directores d on pd.director_id = d.ID\n"
                + "where pd.pelicula_id=?";

        stm = conn.prepareStatement(query);
        stm.setInt(1, idPeli);
        rs = stm.executeQuery();

        while (rs.next()) {
            System.out.println("Nom director: " + rs.getString("Nombre"));
        }
        rs.close();
        stm.close();

    }

    public static void esborrarPeli(int nId) throws SQLException {
        String sql = "DELETE FROM Peliculas WHERE ID = ?";
        String query = "DELETE FROM Peliculas_directores WHERE pelicula_id = ?";
        try {

            PreparedStatement stmt = conn.prepareStatement(sql);

            PreparedStatement myStat = conn.prepareStatement(query);
            if (ifExists("select * FROM Peliculas_directores where pelicula_id = ?", nId)) {

                stmt.setInt(1, nId);

                myStat.setInt(1, nId);

            } else {
                System.out.println("No existeix la pelicula");
            }
            int count = stmt.executeUpdate();
            int cont = myStat.executeUpdate();

            System.out.println("Deleted count: " + count + cont);
            stmt.close();
            myStat.close();

        } catch (Exception e) {
            System.out.println(e.toString());

        }

    }

    public static boolean ifExists(String sSQL, int nId) throws SQLException {
        PreparedStatement ps = conn.prepareStatement(sSQL);
        ps.setInt(1, nId);
        ResultSet rs = ps.executeQuery();
        return rs.next();
    }

    public static void insertaDosDirectors(int idPeli,int idDirector, String nDirector, int idDosDirec, String nDosDirec) throws SQLException {

        PreparedStatement stm;

      
        String xQuery = "INSERT INTO Directores (ID,Nombre) values (?,?)";
        String nQuery = "INSERT INTO Peliculas_directores (pelicula_id,director_id) values(?,?)";
        

        stm = conn.prepareStatement(xQuery);
        stm.setInt(1, idDirector);
        stm.setString(2, nDirector);

        stm = conn.prepareStatement(xQuery);
        stm.setInt(1, idDosDirec);
        stm.setString(2, nDosDirec);

        stm = conn.prepareStatement(nQuery);
        stm.setInt(1, idPeli);
        stm.setInt(2, idDirector);

        stm = conn.prepareStatement(nQuery);
        stm.setInt(1, idPeli);
        stm.setInt(2, idDosDirec);

        int cont = stm.executeUpdate();

        System.out.println("Inserted peli count: " + cont);
        stm.close();

    }

}
