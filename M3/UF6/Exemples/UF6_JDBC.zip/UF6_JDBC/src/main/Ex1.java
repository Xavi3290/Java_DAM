/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

import java.sql.*;

/**
 *
 * @author agustincintas
 */
public class Ex1 {

    static final String driver = "com.mysql.cj.jdbc.Driver";
    static final String url = "jdbc:mysql://localhost:3306/DatosCoches";
    //Nom de la nostra BBDD
    static final String userName = "agustin";
    static final String password = "Adminroot95";
    private static Connection conn = null;
    //  private static Connection conn = null;

    public static void main(String[] args) {

        try {
            conn = DriverManager.getConnection(url, userName, password);

            // Ja hem insertat 3 propietaris i 3 cotxes
            // insertaPropietari("47173517A","Agus",26);
//             insertaPropietari("41133411B","Oscar",27);
//              insertaPropietari("41133411Q","Adri",28);
//           // insertaCotxe("4358JKL", "Citroen", 2000, "47173517A");
//            insertaCotxe("4153JIX", "Ford", 2150, "41133411B");
//            insertaCotxe("4152HLL", "Audi", 3000, "12172518C");
//            insertaCotxe("9067UKL", "Ferrari", 4000, "41133411B");
            consultaCotxe("41133411Q");
            //esborraPropietari("47173517A");

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

    }

    public static void consultaCotxe(String nif) throws SQLException, ClassNotFoundException {

        PreparedStatement stmt;
        ResultSet rs;

        String query = "SELECT pr.Nombre,pr.Edad,co.Matricula,co.Marca,co.Precio FROM DatosCoches.COCHES co\n" +
"inner join DatosCoches.PROPIETARIOS pr on co.DNI=pr.DNI where pr.DNI = ?";

        stmt = conn.prepareStatement(query);
        stmt.setString(1, nif);
        rs = stmt.executeQuery();
        System.out.println("Propietari amb DNI: " + nif);
        while (rs.next()) {
            System.out.println("Nom: "+rs.getString("Nombre"));
            System.out.println("Edad: "+rs.getInt("Edad"));
            System.out.println("Matricula: " + rs.getString("Matricula"));
            System.out.println("Marca: " + rs.getString("Marca"));
            System.out.println("Preu: " + rs.getInt("Precio"));
            System.out.println();

        }
        rs.close();
        stmt.close();
    }

    private static void insertaCotxe(String mat, String mark, int preu, String nif) throws SQLException {
        String query = "INSERT INTO COCHES (Matricula,Marca,Precio,DNI) VALUES (?,?,?,?)";
        try {
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, mat);
            stmt.setString(2, mark);

            if (ifExists("Select * from PROPIETARIOS where DNI = ?;", nif)) {
                stmt.setInt(3, preu);
            } else {

                System.out.println("No Existeix aquest DNI A LA TAULA PROPIETARIS");
            }

            stmt.setString(4, nif);

            int count = stmt.executeUpdate();

            System.out.println("Inserted Cotxe count: " + count);
            stmt.close();
        } catch (Exception e) {
//            System.out.println(e.toString());
        }

    }

    private static void insertaPropietari(String nif, String name, int edat) throws SQLException {

        PreparedStatement stmt;

        String query = "INSERT INTO PROPIETARIOS (DNI,Nombre,Edad) values (?,?,?)";

        stmt = conn.prepareStatement(query);
        stmt.setString(1, nif);
        stmt.setString(2, name);
        stmt.setInt(3, edat);

        int count = stmt.executeUpdate();

        System.out.println("Inserted Cotxe count: " + count);
        stmt.close();

    }

    public static boolean ifExists(String sSQL, String nif) throws SQLException {
        PreparedStatement ps = conn.prepareStatement(sSQL);
        ps.setString(1, nif);
        ResultSet rs = ps.executeQuery();
        return rs.next();
    }

    private static void esborraPropietari(String nif) throws SQLException {
String sql = "DELETE FROM PROPIETARIOS WHERE DNI = ?";
String query = "DELETE FROM COCHES WHERE DNI = ?";
        try {
            
            PreparedStatement stmt = conn.prepareStatement(sql);
            
            PreparedStatement myStat = conn.prepareStatement(query);
            if (ifExists("select * FROM PROPIETARIOS where DNI = ?", nif)) {

                stmt.setString(1, nif);

                myStat.setString(1, nif);
            } else {
                System.out.println("No existeix el PROPIETARI");
            }

            int count = stmt.executeUpdate();
            int count2= myStat.executeUpdate();

            System.out.println("Deleted count: " + count);
            stmt.close();

        } catch (Exception e) {
            
        }

    }
}
