/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package xavierrocauf6.jdbc;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 *
 * @author usuari
 */
public class Ex02 {

    /**
     * @param args the command line arguments
     */
    
    static final String driver = "com.mysql.cj.jdbc.Driver";
    static final String url = "jdbc:mysql://127.0.0.1:3306/";
    static final String dbName = "Cine";                  //Nom de la nostra BBDD
    static final String userName = "xavi";     //cambiar
    static final String password = "xavi";

    private static Connection conn = null;
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        
    }
    
}
