/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package xavierrocauf2metodes2;

/**
 *
 * @author usuari
 */
public class Estudiant {
            
    String nom;
    int edat;
    double[] notes = new double[3];
            
}
