/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package xavierrocauf3arxius;

/**
 *
 * @author usuari
 */
public class Producte {
    
    String codi;
    String descripcio;
    double preu;
    int quantitat;    
}
