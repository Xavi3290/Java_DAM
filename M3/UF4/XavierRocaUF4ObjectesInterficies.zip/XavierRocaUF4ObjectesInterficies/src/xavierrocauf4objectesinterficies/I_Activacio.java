/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package xavierrocauf4objectesinterficies;

/**
 *
 * @author usuari
 */
public interface I_Activacio {
    
    public void activar();
    public double valor();
    public void desactivar();
    public void dades();
   
}
