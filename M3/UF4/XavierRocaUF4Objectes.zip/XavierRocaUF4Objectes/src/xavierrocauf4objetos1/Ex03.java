/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package xavierrocauf4objetos1;

/**
 *
 * @author usuari
 */
public class Ex03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Calculadora.suma(10, 10);
        Calculadora.resta(20, 10);
        Calculadora.multiplicacio(6, 6);
        Calculadora.divisio(4, 2);
        
       
    }
    
}
