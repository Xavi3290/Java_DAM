/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package xavierrocauf5calculadora;

/**
 *
 * @author usuari
 */
public class XavierRocaUF5Calculadora {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    }
    
}
