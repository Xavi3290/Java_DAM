/*
3)  Crea un mètode  que generi diferents excepcions. Aquestes hauran de ser tractades en el mateix mètode. 
Una de les excepcions generades l'hauràs de crear tu de tal forma que obligatòriament s'hagi de capturar.
 */
package Exceptions;

/**
 *
 * @author judit
 */
public class Exercici3 {

    public static void main(String[] args) {

        try {
            int x = 1;
            int y = 0;
            int z = x / y;
        } catch (ArithmeticException e) {
            System.out.println(e.getClass() + "---" + e.getMessage() + "---" + e.toString());
            System.out.println("Error aritmetic!!!");
        }
        try {
            int array[] = {2, 3, 4};
            int x = array[5];
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println(e.getClass() + "---" + e.getMessage() + "---" + e.toString());
            System.out.println("Array index out of bounds!!!");
        }
        try {
           double x = arrelQuadrada(-1);
        } catch (NumImaginariException e) {
            System.out.println(e.toString());
        }

       

    }

    public static double arrelQuadrada(int x) throws NumImaginariException {
        if (x < 0) throw new NumImaginariException();
        return Math.sqrt(x);
    }

}
