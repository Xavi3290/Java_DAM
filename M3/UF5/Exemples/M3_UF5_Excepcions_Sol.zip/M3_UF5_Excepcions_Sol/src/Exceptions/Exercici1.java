package Exceptions;

/*
Busca 4 tipus d'excepcions i crea un codi per cadascuna d'elles on es llenci i es capturi.
 */
/**
 *
 * @author judit
 */
public class Exercici1 {

    public static void main(String[] args) {
        int array[] = {2, 3, 4};
        System.out.println("---------------------");
        System.out.println("indexOutOfBounds");
        indexOutOfBounds(array);
        
        System.out.println("---------------------");
        System.out.println("arithmetic");
        arithmetic(1,0);

        int x = 10;
        Integer y = null;
        
        System.out.println("---------------------");
        System.out.println("nullPointer");
        nullPointer(x,y);

        System.out.println("---------------------");
        System.out.println("negativeArraySize");
        negativeArraySize();

    }

    public static void indexOutOfBounds(int array[]) {

        try {
            System.out.println("Abans d’executar el for");
            for (int i = 0; i <= array.length; i++) {
                System.out.println("Posició " + i + " : " + array[i]);
            }
            System.out.println("Després d’executar el for");

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println(e.getClass() + "---" + e.getMessage() + "---" + e.toString());
            System.out.println("S'ha sortir dels límits!!!");
        }

        System.out.println("Final del programa 1");
    }
    
    public static void arithmetic(int x, int y) {

        try {
            int z= x/y;

        } catch (ArithmeticException e) {
            System.out.println(e.getClass() + "---" + e.getMessage() + "---" + e.toString());
            System.out.println("Error aritmetic!!!");
        }

        System.out.println("Final del programa 2");
    }
    
    public static void nullPointer(int x, Integer y) {

        try {
            //System.out.println("Abans d’executar el for");
            double z = x/y;

        } catch (NullPointerException e) {
            System.out.println(e.getClass() + "---" + e.getMessage() + "---" + e.toString());
            System.out.println("null pointer exception!!!");
        }

        System.out.println("Final del programa 3");
    }
    
    
    public static void negativeArraySize() {
    
        try {
            int array[] = new int[-1];
            System.out.println("Abans d’executar el for");
            for (int i = 0; i <= array.length; i++) {
                System.out.println("Posició " + i + " : " + array[i]);
            }
            System.out.println("Després d’executar el for");

        } catch (NegativeArraySizeException e) {
            System.out.println(e.getClass() + "---" + e.getMessage() + "---" + e.toString());
            System.out.println("negative array size!!!");
        }

        System.out.println("Final del programa 4");
    }
    

}
