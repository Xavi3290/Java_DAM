package Exceptions;

/*
Posa un exemple d'un codi que es capturi i es resolgui una excepció després de ser propagada.
 */
/**
 *
 * @author judit
 */
public class Exercici2 {

    public static void main(String[] args) {
        try {
            funcio();
        } catch (NegativeArraySizeException e) {
            System.out.println(e.getClass() + "---" + e.getMessage() + "---" + e.toString());
            System.out.println("negative array size!!!");
            e.printStackTrace();
        }

        System.out.println("Final del programa");
    }

    public static void funcio()  {
        int array[] = new int[-1];

        for (int i = 0; i <= array.length; i++) {
            System.out.println("Posició " + i + " : " + array[i]);
        }

        //throw new NegativeArraySizeException();
    }

}
