/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exceptions;

import java.lang.Math;

/**
 *
 * @author judit
 */
public class NumImaginariException extends Exception {

    public NumImaginariException() {
        super("El resultat es un número imaginari");
    }
}
