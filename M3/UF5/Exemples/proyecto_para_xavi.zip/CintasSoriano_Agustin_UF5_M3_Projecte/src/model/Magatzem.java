/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

/**
 *
 * @author agustincintas
 */
public class Magatzem implements Serializable {

    Set<Videojoc> productes = new TreeSet<>();

    public Magatzem() {
    }

    public Set<Videojoc> getProductes() {
        return productes;
    }

    public void setProductes(Set<Videojoc> productes) {
        this.productes = productes;
    }

    public void afegirProducte(Videojoc a) {
        productes.add(a);

    }

    public void mostra() {
        for (Videojoc v : productes) {
            System.out.println(v.dades());
        }
    }
    
    public boolean codiDuplicat(int cod){
        if(productes.isEmpty()){
            return false;
        }else{
            for (Videojoc v : productes) {
                if(v.getCodi()==cod){
                    return true;
                }
                
            }
        }
        return false;
    }
    

    
}
