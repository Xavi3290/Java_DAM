/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.io.Serializable;

/**
 *
 * @author agustincintas
 */
public class Videojoc implements Comparable<Videojoc>,Serializable{
    private int codi;
    private String nomjoc;
    private Categoria cate;
    private String plataforma;
    private String tematica;
    private int quantitat;
    private double preu;

    public Videojoc(int codi, String nomjoc, Categoria cate, String plataforma, String tematica, int quantitat, double preu) {
        this.codi = codi;
        this.nomjoc = nomjoc;
        this.cate = cate;
        this.plataforma = plataforma;
        this.tematica = tematica;
        this.quantitat = quantitat;
        this.preu = preu;
    }
      public Videojoc() {
      
    }

    
    
    
    
    public int getCodi() {
        return codi;
    }

    public void setCodi(int codi) {
        this.codi = codi;
    }

    public String getNomjoc() {
        return nomjoc;
    }

    public void setNomjoc(String nomjoc) {
        this.nomjoc = nomjoc;
    }

    public Categoria getCate() {
        return cate;
    }

    public void setCate(Categoria cate) {
        this.cate = cate;
    }

    public String getPlataforma() {
        return plataforma;
    }

    public void setPlataforma(String plataforma) {
        this.plataforma = plataforma;
    }

    public String getTematica() {
        return tematica;
    }

    public void setTematica(String tematica) {
        this.tematica = tematica;
    }


    public int getQuantitat() {
        return quantitat;
    }

    public void setQuantitat(int quantitat) {
        this.quantitat = quantitat;
    }

    public double getPreu() {
        return preu;
    }

    public void setPreu(double preu) {
        this.preu = preu;
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 59 * hash + this.codi;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Videojoc other = (Videojoc) obj;
        if (this.codi != other.codi) {
            return false;
        }
        return true;
    }

    @Override
    public int compareTo(Videojoc v) {
        return this.codi-v.codi;
        
    }


    public String dades() {
        return "Videojoc{" + "codi=" + codi + ", nomjoc=" + nomjoc + ", Categoria=" + cate.getNom() + ", plataforma=" + plataforma + ", tematica=" + tematica + ", quantitat=" + quantitat + ", preu=" + preu + '}';
    }

    

   
    
    
}
