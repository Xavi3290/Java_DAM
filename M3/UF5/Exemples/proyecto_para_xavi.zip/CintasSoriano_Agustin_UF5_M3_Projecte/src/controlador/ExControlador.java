/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import cintassoriano_agustin_uf5_m3_projecte.util.Util;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Set;
import java.util.TreeSet;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import model.Categoria;
import model.Magatzem;
import model.Videojoc;
import view.Ventana;
import view.VentanaMenu;

/**
 *
 * @author agustincintas
 */
public class ExControlador {

    private final String nomFitxer = "productes.obj";
    private File fi;
    private Ventana frm;
    private Magatzem magatzem;
    private VentanaMenu vm;
    
    public ExControlador() {
        this.fi = new File(nomFitxer);
        this.frm = new Ventana(this);
        this.frm.setVisible(true);
        this.vm = new VentanaMenu(this.frm, true, this);
        
        if (fi.exists()) {
            try {
                magatzem = lecturaMagatzem(nomFitxer);
            } catch (Exception e) {
                System.out.println("ERRORR");
            }
            
        } else {
            magatzem = new Magatzem();
        }
    }
    
    public void afegirVideojoc(Videojoc a) {
        magatzem.afegirProducte(a);
        JOptionPane.showMessageDialog(this.frm, "Joc introduit amb exit", "Perfecte!", JOptionPane.INFORMATION_MESSAGE);
        magatzem.mostra();
        grabarFitxer();
        
    }

    public void grabarFitxer() {
        
        try {
            
            FileOutputStream fos = new FileOutputStream(nomFitxer);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            
            oos.writeObject(magatzem);
            oos.close();
            
        } catch (Exception e) {
            System.out.println(e.toString());
        }
        
    }
    
    
  

    public void mostraLlista() {
        VentanaMenu dialog = new VentanaMenu(this.frm, true, this);
        TableModel tm = this.getDadesMagatzemDataTable();
        dialog.setInfo(tm);
        dialog.setLocationRelativeTo(null);
        dialog.setVisible(true);
        
    }
    
    public Magatzem lecturaMagatzem(String fitxer) {
        Magatzem mag = null;
        ObjectInputStream ois = null;
        
        try {
            FileInputStream fis = new FileInputStream(fitxer);
            ois = new ObjectInputStream(fis);
            while (true) {
                mag = (Magatzem) ois.readObject();
                mag.mostra();
                System.out.println();
                
            }
            
        } catch (EOFException exc) {
            System.out.println("\n**************** FIN ARXIU**************");
        } catch (Exception e) {
            System.out.println(e.toString());
        } finally {
            try {
                if (ois != null) {
                    ois.close();
                }
            } catch (IOException e) {
                System.out.println(e.toString());
            }
        }
        return mag;
        
    }
    
    private TableModel getDadesMagatzemDataTable() {
        DefaultTableModel tm = new DefaultTableModel();
        tm.addColumn("Codi");
        tm.addColumn("Plataforma");
        tm.addColumn("Nom");
        tm.addColumn("Quantitat");
        tm.addColumn("Preu");
        tm.addColumn("Categoria");
        tm.addColumn("Tematica");
        
        Set<Videojoc> videojocs = magatzem.getProductes();
        for (Videojoc vi : videojocs) {
            Object[] fila = new Object[7]; // Hay tres columnas en la tabla
            // Se rellena cada posición del array con una atributo de Alumne.
            fila[0] = vi.getCodi();
            fila[1] = vi.getPlataforma();
            fila[2] = vi.getNomjoc();
            fila[3] = vi.getQuantitat();
            fila[4] = vi.getPreu();
            fila[5] = vi.getCate().getNom();
            fila[6] = vi.getTematica();            
            tm.addRow(fila);
        }
        return tm;
    }
    
}
