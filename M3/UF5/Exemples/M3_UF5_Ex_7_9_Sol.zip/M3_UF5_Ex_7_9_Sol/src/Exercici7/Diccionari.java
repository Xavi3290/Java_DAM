/*
7)  Fes una classe Diccionari utilitzant la classe HashMap:
a)  Fent que la nom i el nom siguin String.
b)  Fent que la nom sigui un String  i el nom siguin una classe Paraula amb atributs: 
nom, idioma i significat gramatical ( adjectiu, preposició,...)
 */
package Exercici7;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 *
 * @author judit
 */
public class Diccionari {

    private String nomDic;
    Map<String, Paraula> diccionari = new TreeMap<>();

    public Diccionari(String nomdic) {
        this.nomDic = nomdic;
    }

    public String getNom() {
        return nomDic;
    }

    public void setNom(String nom) {
        this.nomDic = nom;
    }

    public void afegirParaula(Paraula pa) {
        diccionari.put(pa.getNom(), pa);
    }

    public void esborrarParaula(Paraula pa) {
        diccionari.remove(pa.getNom());
    }

    public void esborrarParaula(String nom) {
        diccionari.remove(nom);
    }

    public Paraula getParaula(String clau) {
        return this.diccionari.get(clau);
    }

    public void mostrarParaules() {

        Set<String> ks = this.diccionari.keySet();

        System.out.println("--Amb Enhanced For per Claus-----");
        for (String key : ks) {
            System.out.println(this.getParaula(key));
        }

        System.out.println("--Amb Iterador de Claus-----");
        Iterator<String> it = ks.iterator();
        while (it.hasNext()) {
            String key = it.next();
            System.out.println(this.getParaula(key));
        }

    }

    @Override
    public String toString() {
        return "Diccionari:" + " clau: " + nomDic + ", diccionari: " + diccionari + '}';
    }

}
