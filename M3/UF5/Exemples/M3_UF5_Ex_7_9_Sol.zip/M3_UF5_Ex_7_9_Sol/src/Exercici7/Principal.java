/*
7)  Fes una classe Diccionari utilitzant la classe HashMap:
a)  Fent que la clau i el nom siguin String.
b)  Fent que la clau sigui un String  i el nom siguin una classe Paraula amb atributs: 
nom, idioma i significat gramatical ( adjectiu, preposició,...)
 */
package Exercici7;

/**
 *
 * @author judit
 */
public class Principal {

    public static void main(String[] args) {
        Diccionari diccionari = new Diccionari("Diccionari Mini");

        Paraula p2 = new Paraula("Blau", "Color primari, entre el verd i el violeta", "Cat", "adj");
        Paraula p3 = new Paraula("Maria", "Nom de dona", "Cat", "nom");
        Paraula p4 = new Paraula("Sobre", "Damunt, tocant a ", "Cat", "prep");
        Paraula p1 = new Paraula("Comprar", "Adquirir bens o serveis", "Cat", "prep");

        diccionari.afegirParaula(p1);
        diccionari.afegirParaula(p2);
        diccionari.afegirParaula(p3);
        diccionari.afegirParaula(p4);

        diccionari.mostrarParaules();
        System.out.println("--get per clau: 'Blau'------");
        Paraula p = diccionari.getParaula("Blau");
        System.out.println(p.toString());
        System.out.println("--Esborrar per clau: 'Blau'------");
        diccionari.esborrarParaula("Blau");
        diccionari.mostrarParaules();

    }

}
