/*
7)  Fes una classe Diccionari utilitzant la classe HashMap:
a)  Fent que la clau i el nom siguin String.
b)  Fent que la clau sigui un String  i el nom siguin una classe Paraula amb atributs: 
nom, idioma i significat gramatical ( adjectiu, preposició,...)
 */
package Exercici7;

/**
 *
 * @author judit
 */
public class Paraula {
    
    private String nom;
    private String definicio;
    private String idioma;
    private String tipus;

    public Paraula(String nom, String definicio, String idioma, String significat) {
        this.nom = nom;
        this.definicio = definicio;
        this.idioma = idioma;
        this.tipus = significat;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDefinicio() {
        return definicio;
    }

    public void setDefinicio(String definicio) {
        this.definicio = definicio;
    }

    public String getIdioma() {
        return idioma;
    }

    public void setIdioma(String idioma) {
        this.idioma = idioma;
    }

    public String getTipus() {
        return tipus;
    }

    public void setTipus(String tipus) {
        this.tipus = tipus;
    }

    @Override
    public String toString() {
        return "Paraula{" + "nom=" + nom + ", definicio=" + definicio + ", idioma=" + idioma + ", tipus=" + tipus + '}';
    }
    
    
}
