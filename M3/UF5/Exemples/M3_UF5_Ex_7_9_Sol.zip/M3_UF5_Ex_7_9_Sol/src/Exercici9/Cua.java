/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercici9;

import java.util.LinkedList;

/**
 *
 * @author david
 * @param <T>
 */
public class Cua<T> {

    public LinkedList<T> elementos;

    public Cua() {
        elementos = new LinkedList();
    }
    
    public int size(){
        return elementos.size();
    }

    public boolean empty() {
        return elementos.isEmpty();
    }

    public void add(T e) {
        elementos.add(e);
    }

    public T get() { // pop muestra del ultimo al primero
        T ele = null;
        if (!empty()){
            ele = elementos.removeFirst();
        }
        return ele;
        
    }
    
}
