/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercici9;

/**
 *
 * @author david
 */
public class Caixa extends Cua<Client> {

    protected double acumDiners = 0;

    @Override
    public Client get() {
        Client ele = null;
        if (!empty()) {
            ele = super.get();
            acumDiners += ele.recompte();
        }
        return ele;

    }
}
