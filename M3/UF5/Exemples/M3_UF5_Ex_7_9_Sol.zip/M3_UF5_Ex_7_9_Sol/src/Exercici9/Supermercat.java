/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercici9;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author david
 */
public class Supermercat {

    ArrayList<Caixa> caixes = new ArrayList<>();

    public Supermercat() {

        for (int i = 0; i < 5; i++) {
            Caixa c = new Caixa();
            caixes.add(c);
        }
    }

    public void afegirClient(Client c) {
        if (!caixes.isEmpty()) {
            int min = caixes.get(0).size();
            int pos = 0;
            for (int i = 1; i < caixes.size(); i++) {
                if (min > caixes.get(i).size()) {
                    min = caixes.get(i).size();
                    pos = i;
                }
            }
            System.out.println("Afegim el client " + c + " a la caixa nº" + pos + ".");
            caixes.get(pos).add(c);

        } else {
            System.out.println("No hi han caixes!");
        }

    }

    public Client treureClient() {
        Random rnd = new Random();

        if (!caixes.isEmpty()) {
            Caixa c;
            int pos;
            do {
                pos = rnd.nextInt(caixes.size());
                c = caixes.get(pos);
            } while (c.empty());

            Client cln = c.get();

            System.out.println("El client " + cln + " surt del super per la caixa nº" + pos + " i es gasta un total de " + cln.recompte() + ".");
            return cln;
        }
        return null;
    }

    public void mostrarRecompteCaixes() {
        for (int i = 0; i < caixes.size(); i++) {
            Caixa c = caixes.get(i);
            System.out.println("Caixa nº" + i + ": " + c.acumDiners);
        }
    }

    public boolean empty() {
        boolean vacio = true;
        Caixa c;
        for (int i = 0; i < caixes.size(); i++) {
            c = caixes.get(i);
            if (!c.empty()) {
                vacio = false;
            }
        }

        return vacio;
    }
}
