/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercici9;

/**
 *
 * @author david
 */
public class Exercici09 {

    public static void main(String[] args) {

        Supermercat SuperRodas = new Supermercat();

        Client David = new Client("David", "49641314T");
        Client Sergi = new Client("Sergi", "98541647U");
        Client Jorge = new Client("Jorge", "34650187O");
        Client Marc = new Client("Marc", "52149863P");
        Client Alex = new Client("Alex", "54731982Q");
        Client Carlos = new Client("Carlos", "51796458L");

        Producte carn = new Producte("Carn", 1, 5.4);
        Producte peix = new Producte("Peix", 2, 3.5);
        Producte ous = new Producte("Ous", 3, 6.4);
        Producte patates = new Producte("Patates", 4, 2.4);
        Producte llet = new Producte("Llet", 5, 1.4);

        David.afegirProducte(carn);
        David.afegirProducte(peix);
        David.afegirProducte(ous);
        David.afegirProducte(patates);
        David.afegirProducte(llet);

        Sergi.afegirProducte(carn);
        Sergi.afegirProducte(peix);
        Sergi.afegirProducte(ous);
        Sergi.afegirProducte(patates);

        Jorge.afegirProducte(carn);
        Jorge.afegirProducte(peix);
        Jorge.afegirProducte(ous);

        Marc.afegirProducte(carn);
        Marc.afegirProducte(peix);

        Alex.afegirProducte(carn);

        Carlos.afegirProducte(carn);

        SuperRodas.afegirClient(David);
        SuperRodas.afegirClient(Sergi);
        SuperRodas.afegirClient(Jorge);
        SuperRodas.afegirClient(Marc);
        SuperRodas.afegirClient(Alex);
        SuperRodas.afegirClient(Carlos);

        System.out.println("");
        while (!SuperRodas.empty()) {
            SuperRodas.treureClient();
        }
        System.out.println("");
        SuperRodas.mostrarRecompteCaixes();

    }
}
