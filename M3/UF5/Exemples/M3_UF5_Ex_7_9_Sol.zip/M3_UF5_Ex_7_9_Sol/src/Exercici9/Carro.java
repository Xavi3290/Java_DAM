/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercici9;

import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 *
 * @author david
 */
public class Carro {

    double totalDiners = 0;

    Map<String, Producte> productes = new TreeMap<>();

    public void add(Producte p) {
        productes.put(p.getNom(), p);
        totalDiners += p.getPreu();
    }

    public void isEmpty() {
        productes.isEmpty();
    }

    public void mostrar() {
        Set<String> ks = productes.keySet();
        for (String key : ks) {
            Producte p = productes.get(key);
            p.mostrar();
        }
    }

}
