/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercici9;

/**
 *
 * @author david
 */
public class Producte implements Comparable<Producte> {

    private String nom;
    private int id;
    private double preu;

    public Producte(String nom, int id, double preu) {
        this.nom = nom;
        this.id = id;
        this.preu = preu;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getPreu() {
        return preu;
    }

    public void setPreu(double preu) {
        this.preu = preu;
    }

    @Override
    public int compareTo(Producte p) {
        if (this.nom.compareTo(p.nom) != 0) {
            return this.nom.compareTo(p.nom);
        } else {
            
            double result = (p.getPreu() - this.getPreu());

            return (int) result;

        }
    }
    
    public void mostrar(){
        System.out.println("Nom: " + nom + ", ID: " + id + ", Preu: " + preu + ".");
    }

}
