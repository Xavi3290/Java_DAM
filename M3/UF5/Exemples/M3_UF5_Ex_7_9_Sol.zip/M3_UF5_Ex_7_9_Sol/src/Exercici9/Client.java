/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercici9;

/**
 *
 * @author david
 */
public class Client {

    String nom;
    String dni;
    Carro carro = new Carro();

    public Client(String nom, String dni) {
        this.nom = nom;
        this.dni = dni;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public double recompte() {
        return carro.totalDiners;
    }
    
    public void afegirProducte(Producte p){
        carro.add(p);
    }

    public void mostrar() {
        System.out.println("Nom: " + nom
                + "\nDni: " + dni
                + "\nCARRO");
        carro.mostrar();
    }

    @Override
    public String toString() {
        return  nom;
    }
    
    

}
