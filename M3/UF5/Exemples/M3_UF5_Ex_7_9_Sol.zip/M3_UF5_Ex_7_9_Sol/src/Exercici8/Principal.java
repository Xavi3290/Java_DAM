/*
8)  Fes una classe “Agenda de contactes” utilitzant la col·lecció de Java adient. 
Més concretament cada contacte constarà de quatre Strings: nom, adreça, població i telèfon. 
L'Agenda haurà de contenir mètodes per: mostrar les dades d'un contacte donat el nom, 
afegir un contacte, eliminar un contacte,  mostrar els contactes ordenats per nom, 
mostrar tots els contactes que tenen un nom que comenci amb una lletra passada per paràmetre, 
mostrar tots els contactes que viuen en una població que comença per un String determinat (“Sant” o San”...)
 */
package Exercici8;

/**
 *
 * @author Judith
 */
public class Principal {

    public static void main(String[] args) {
        Agenda agenda = new Agenda("Contactes");
        Contacte p1 = new Contacte("Judit", "Avinguda", "La llagosta", "666555777");
        Contacte p2 = new Contacte("Victor", "Carrer", "Franqueses", "666555444");
        Contacte p3 = new Contacte("Cristian", "Carrer", "Montornes", "666555333");
        Contacte p4 = new Contacte("Marc", "Avinguda", "Mollet", "666777888");
        Contacte p5 = new Contacte("Pep", "Avinguda", "Mollet", "666777889");


        agenda.afegirContacte(p1);
        agenda.afegirContacte(p2);
        agenda.afegirContacte(p3);
        agenda.afegirContacte(p4);
        agenda.afegirContacte(p5);
        
        System.out.println("----Llista contactes----");
        agenda.mostrarContactes();

        System.out.println("----Contactes que comencen per la lletra 'C'----");
        agenda.mostrarContactes1aLletraNom('C');

        System.out.println("----Contactes que viuen en una poblacio que comença per 'La'----");
        agenda.mostrarContactesPoblacio("La");
        
        System.out.println("---Cercar: 'Marc'-----");
        System.out.println(agenda.cercarContacte("Marc"));

    }
}
