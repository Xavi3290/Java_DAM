/**
 * 8)  Fes una classe “Agenda de contactes” utilitzant la col·lecció de Java adient.
 * Més concretament cada contacte constarà de quatre Strings: nom, adreça, població i telèfon.
 * L'Agenda haurà de contenir mètodes per: mostrar les dades d'un contacte donat el nom,
 * afegir un contacte, eliminar un contacte,  mostrar els contactes ordenats per nom,
 * mostrar tots els contactes que tenen un nom que comenci amb una lletra passada per paràmetre,
 * mostrar tots els contactes que viuen en una població que comença per un String determinat (“Sant” o San”...)
 */
package Exercici8;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 *
 * @author Judith
 */
public class Agenda {

    String nomAgenda;
//  Amb TreeMap no caldria  llistar amb un Map auxiliar
//  Map<String, Contacte> agenda = new TreeMap<>();
    Map<String, Contacte> agenda = new HashMap<>();

    public Agenda(String noma) {
        this.nomAgenda = noma;
    }

    public void afegirContacte(Contacte co) {
        agenda.put(co.nom, co);
    }

    public Contacte esborrarContacte(String nom) {
        return agenda.remove(nom);
    }

    public Contacte cercarContacte(String nom) {
        return this.agenda.get(nom);
    }

    public void mostrarContactes() {
        // Com es una HashMap si volem ordre creem un TreeSet de les Claus
        TreeSet<String> ks = new TreeSet(this.agenda.keySet());

        for (String key : ks) {
            System.out.println(cercarContacte(key));
        }
        /*
        //  També podem utilitzar l'iterador del TreeSet de claus
        Iterator<String> it = ks.iterator();
        while (it.hasNext()) {
            String key = it.next();
            System.out.println(entradaAgenda(key));
        }
         */
    }

    public void mostrarContactes1aLletraNom(char a) {
        // Amb Enanced-for de clau (ordre natural string si es TreeMap, sense ordre si es HashMap)
        Set<String> ks = this.agenda.keySet();
        for (String key : ks) {
            if (key.charAt(0) == a) {
                System.out.println(cercarContacte(key));
            }
        }
    }

    public void mostrarContactesPoblacio(String po) {
        // Amb Iterador de clau (ordre natural string si es TreeMap, sense ordre si es HashMap)
        Set<String> ks = this.agenda.keySet();
        //Iterator<String> it = ks.iterator();
        Contacte contacte;
        for (String key : ks) {
            contacte = agenda.get(key);
            if (contacte.poblacio.startsWith(po)) {
                System.out.println(contacte.toString());
            }
        }
    }

    public String getNomAgenda() {
        return nomAgenda;
    }

    public void setNomAgenda(String nomAgenda) {
        this.nomAgenda = nomAgenda;
    }

    @Override
    public String toString() {
        return "Agenda:" + " Nom: " + nomAgenda + ", diccionari: " + agenda + '}';
    }
}
