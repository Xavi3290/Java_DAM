/*
8)  Fes una classe “Agenda de contactes” utilitzant la col·lecció de Java adient. 
Més concretament cada contacte constarà de quatre Strings: nom, adreça, població i telèfon. 
L'Agenda haurà de contenir mètodes per: mostrar les dades d'un contacte donat el nom, 
afegir un contacte, eliminar un contacte,  mostrar els contactes ordenats per nom, 
mostrar tots els contactes que tenen un nom que comenci amb una lletra passada per paràmetre, 
mostrar tots els contactes que viuen en una població que comença per un String determinat (“Sant” o San”...)
 */
package Exercici8;

/**
 *
 * @author Judith
 */
public class Contacte {

    protected String nom;
    protected String adreca;
    protected String poblacio;
    protected String telefon;

    public Contacte(String nom, String adreca, String poblacio, String telefon) {
        this.nom = nom;
        this.adreca = adreca;
        this.poblacio = poblacio;
        this.telefon = telefon;
    }
    
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getAdreca() {
        return adreca;
    }

    public void setAdreca(String adreca) {
        this.adreca = adreca;
    }

    public String getPoblacio() {
        return poblacio;
    }

    public void setPoblacio(String poblacio) {
        this.poblacio = poblacio;
    }

    public String getTelefon() {
        return telefon;
    }

    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

    @Override
    public String toString() {
        return "Contacte: " + "nom: " + nom + ", adreca: " + adreca + ", poblacio: " + poblacio + ", telefon: " + telefon;
    }
}
