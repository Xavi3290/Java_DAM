/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex3;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author ruben
 * 
 */
class Alumne implements Serializable {

    protected String nom;
    protected transient int edat;
    protected ArrayList<Nota> notes = new ArrayList<>();

    public Alumne(String nom, int edat) {
        this.nom = nom;
        this.edat = edat;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getEdat() {
        return edat;
    }

    public void setEdat(int edat) {
        this.edat = edat;
    }

    public ArrayList<Nota> getNotes() {
        return notes;
    }

    public void setNotes(Nota not) {
        this.notes.add(not);
    }

    @Override
    public String toString() {
        return "Alumne{" + "nom=" + nom + ", edat=" + edat + ", notes=" + notes + '}';
    }


}