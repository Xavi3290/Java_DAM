/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex3;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

/**
 *
 * @author ruben
 *
 */
class Curs {

    protected String nom;
    protected ArrayList<Alumne> llistatAlumnes = new ArrayList<>();

    public Curs(String nom) {
        this.nom = nom;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void afegirAlumne(Alumne al) {
        this.llistatAlumnes.add(al);
    }

    public void recuperarAllumnes() {
        this.llistatAlumnes = new ArrayList<Alumne>();
        ObjectInputStream ois = null;

        try {
            File f = new File("dades/alumnes.obj");
            FileInputStream fis = new FileInputStream(f);
            ois = new ObjectInputStream(fis);
            this.llistatAlumnes = (ArrayList<Alumne>) ois.readObject();
            ois.close();
        } catch (Exception io) {
            System.out.println("Error" + io);
        }
    }

    public void emmagatzemarAlumnes() {
        ObjectOutputStream oos = null;
        FileOutputStream fos = null;
        try {
            File f = new File("dades/alumnes.obj");
            fos = new FileOutputStream(f);
            oos = new ObjectOutputStream(fos);
            oos.writeObject(this.llistatAlumnes);
            oos.close();
        } catch (Exception e) {
            System.out.println(e);
        }

    }

    @Override
    public String toString() {
        return "Curs{" + "nom=" + nom + ", alu=" + llistatAlumnes + '}';
    }

    public void mostra() {

        System.out.println("Curs: " + this.nom);
        for (int i = 0; i < this.llistatAlumnes.size(); i++) {
            System.out.println("Alu: " + this.llistatAlumnes.get(i).toString());
        }
        System.out.println();

    }

}
