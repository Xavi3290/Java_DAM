/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex3;

/**
 *
 * @author ruben
 */
public class Main {

    public static void main(String[] args) {
        Nota n1_1 = new Nota("M6", 8);
        Nota n1_2 = new Nota("M7", 4);
        Nota n2_1 = new Nota("M6", 9);
        Nota n2_2 = new Nota("M7", 6);
        Nota n3_1 = new Nota("M6", 4);
        Nota n3_2 = new Nota("M7", 1);

        Alumne alumne1 = new Alumne("Ruben", 23);
        Alumne alumne2 = new Alumne("Bernardo", 24);
        Alumne alumne3 = new Alumne("Alex", 18);

        alumne1.setNotes(n1_1);
        alumne1.setNotes(n1_2);
        alumne2.setNotes(n2_1);
        alumne2.setNotes(n2_2);
        alumne3.setNotes(n3_1);
        alumne3.setNotes(n3_2);

        Curs curs = new Curs("DAW");
        curs.afegirAlumne(alumne1);
        curs.afegirAlumne(alumne2);
        curs.afegirAlumne(alumne3);
        curs.mostra();
        
        curs.emmagatzemarAlumnes();

        Curs cc = new Curs("2DAW");
        cc.recuperarAllumnes();
        cc.mostra();
    }
}
