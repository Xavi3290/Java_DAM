/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex2;
import java.io.Serializable;


/**
 *
 * @author ruben
 * 
 */
class Nota implements Serializable {

    protected String modul;  
    protected int nota;

    public Nota(String modul, int nota) {
        this.modul = modul;
        this.nota = nota;
    }

    public String getModul() {
        return modul;
    }

    public void setModul(String modul) {
        this.modul = modul;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }
    
     @Override
    public String toString() {
        return "Nota{"+ ", modul=" + modul  + "puntuacio=" + nota + '}';
    }
    

    
    
}