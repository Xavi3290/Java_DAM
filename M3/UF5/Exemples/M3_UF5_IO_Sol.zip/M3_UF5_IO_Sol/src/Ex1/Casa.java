/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex1;

import java.io.Serializable;

/**
 *
 * @author ruben
 * 
 */
class Casa implements Serializable {

    protected String carrer;
    protected String ciutat;
    protected Propietari propietari;
    protected int nInquilins;

    public Casa(String carrer, String ciutat, Propietari propietari, int nInquilins) {
        this.carrer = carrer;
        this.ciutat = ciutat;
        this.propietari = propietari;
        this.nInquilins = nInquilins;
    }

    public String getCarrer() {
        return carrer;
    }

    public void setCarrer(String carrer) {
        this.carrer = carrer;
    }

    public String getCiutat() {
        return ciutat;
    }

    public void setCiutat(String ciutat) {
        this.ciutat = ciutat;
    }

    public Propietari getPropietari() {
        return propietari;
    }

    public void setPropietari(Propietari propietari) {
        this.propietari = propietari;
    }

    public int getnInquilins() {
        return nInquilins;
    }

    public void setnInquilins(int nInquilins) {
        this.nInquilins = nInquilins;
    }
    
    
    
    
}