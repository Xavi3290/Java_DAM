/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex1;

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author ruben
 */
public class Main {

    //Crea un main per crear dos objectes casa.
    //Després serialitza'ls i guarda'ls en un arxiu
    //anomenat “dades”. Finalment recupera'ls  i mostra
    //la informació recuperada per pantalla.
    public static void main(String[] args) {
        Propietari propietari1 = new Propietari("Ruben", "12451245-x");
        Propietari propietari2 = new Propietari("Manel", "12451745-x");
        Casa casa1 = new Casa("C/ sevilla", "Granollers", propietari1, 8);
        Casa casa2 = new Casa("C/ merengue", "Barcelona", propietari2, 4);
        
        try {
            File f = new File("dades.obj"); //Creo l'arxiu
            FileOutputStream fos = new FileOutputStream(f);//Se'l passo
            ObjectOutputStream oos = new ObjectOutputStream(fos);// així mateix se'l passo 
            oos.writeObject(casa1);
            oos.writeObject(casa2);
            oos.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        mostrarArxiu("dades.obj");
    }


    public static void mostrarArxiu(String arxiu) {
        Casa p = null;
        ObjectInputStream ois = null;
        try {
            File f = new File(arxiu);
            FileInputStream fis = new FileInputStream(f);
            ois = new ObjectInputStream(fis);
            while (true) {
                p = (Casa) ois.readObject();
                System.out.println("Carrer: " + p.getCarrer());
                System.out.println("Ciutat: " + p.getCiutat());
                System.out.println("Numero Inquilins: " + p.getnInquilins());
                System.out.println("Propietari: " + p.getPropietari().getNom() + "(" + p.getPropietari().getDni() + ")");
                System.out.println("*********************");

            }
        } catch (EOFException exc) {
            System.out.println("\n**************** FIN ARXIU**************");
        } catch (Exception io) {
            System.out.println("Error" + io);
        } finally {
            if (ois != null) {
                try {
                    ois.close();
                } catch (Exception io) {
                    System.out.println("Error" + io);
                }
            }
        }
        System.out.println("Fin programa");
    }

}
