/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex1;

import java.io.Serializable;

/**
 *
 * @author ruben
 * 
 */
class Propietari implements Serializable {

    protected String nom;
    protected  String dni;
    //transient
    public Propietari(String nom, String dni) {
        this.nom = nom;
        this.dni = dni;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    @Override
    public String toString() {
        return "Propietari{" + "nom=" + nom + ", dni=" + dni + '}';
    }
   
}