/*
6)  Fes una classe Empresa que  a més dels mètodes habituals tingui els següents mètodes:
a)  Mostrar llistat per treballadors ordenats pel sou ( primer el que més guanya)
b)  Mostrar llistat treballadors ordenats primer per nom i després per cognom
c)  Mostrar llistat treballador ordenats primer per càrrec i deprès per dni.
 */
package Exercici6;

/**
 *
 * @author judit
 */
public class Principal {

    public static void main(String[] args) {

        Empresa empresa = new Empresa();
        Treballador tre1 = new Treballador("Victor", "Auyanet", "11111", 1100, "1");
        Treballador tre2 = new Treballador("Marc", "Ortega", "22222", 1400, "2");
        Treballador tre3 = new Treballador("Cristian", "Zambrano", "33333", 1500, "2");
        Treballador tre4 = new Treballador("Marc", "Auyanet", "44444", 1100, "2");
        Treballador tre5 = new Treballador("Judit", "Moya", "55555", 1200, "1");
        Treballador tre6 = new Treballador("Victor", "Auyanet", "66666", 1100, "1");

        empresa.add(tre1);
        empresa.add(tre2);
        empresa.add(tre3);
        empresa.add(tre4);
        empresa.add(tre5);
        System.out.println(empresa.add(tre6));
        System.out.println("\nMostrar llistat treballadors ordenats primer per nom i després per cognom (Natural)");
        System.out.println("------------------------------------------------------------------------------");
        empresa.mostrarCognomNom();

    }
}
