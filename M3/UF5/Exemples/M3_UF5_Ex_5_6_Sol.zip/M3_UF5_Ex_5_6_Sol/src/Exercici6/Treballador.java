/*
6)  Fes una classe Empresa que  a més dels mètodes habituals tingui els següents mètodes:
a)  Mostrar llistat per treballadors ordenats pel sou ( primer el que més guanya)
b)  Mostrar llistat treballadors ordenats primer per nom i després per cognom
c)  Mostrar llistat treballador ordenats primer per càrrec i deprès per dni.
 */
package Exercici6;

import java.util.Objects;

/**
 *
 * @author
 */
class Treballador implements Comparable<Treballador> {

    protected String nom;
    protected String cognom;
    protected String dni;
    protected int sou;
    protected String carrec;

    public Treballador(String nom, String cognom, String dni, int sou, String carrec) {
        this.nom = nom;
        this.cognom = cognom;
        this.dni = dni;
        this.sou = sou;
        this.carrec = carrec;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getCognom() {
        return cognom;
    }

    public void setCognom(String cognom) {
        this.cognom = cognom;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public int getSou() {
        return sou;
    }

    public void setSou(int edad) {
        this.sou = edad;
    }

    public String getCarrec() {
        return carrec;
    }

    public void setCarrec(String carrec) {
        this.carrec = carrec;
    }

    @Override
    public String toString() {
        return "Treballador{" + "nom=" + nom + ", cognom=" + cognom + ", dni=" + dni + ", sou=" + sou + ", carrec=" + carrec + '}';
    }

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 37 * hash + Objects.hashCode(this.nom);
        hash = 37 * hash + Objects.hashCode(this.cognom);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Treballador other = (Treballador) obj;
        if (!Objects.equals(this.nom, other.nom)) {
            return false;
        }
        return Objects.equals(this.cognom, other.cognom);
    }

    @Override
    public int compareTo(Treballador o) {

        int result = this.cognom.compareTo(o.cognom);

        if (result == 0) {
            result = this.nom.compareTo(o.nom);
        }
        return result;
    }

}
