/*
6)  Fes una classe Empresa que  a més dels mètodes habituals tingui els següents mètodes:
a)  Mostrar llistat per treballadors ordenats pel sou ( primer el que més guanya)
b)  Mostrar llistat treballadors ordenats primer per nom i després per cognom
c)  Mostrar llistat treballador ordenats primer per càrrec i deprès per dni.
 */
package Exercici6;

import java.util.TreeSet;

/**
 *
 * @author judit
 */
public class Empresa {

    TreeSet<Treballador> treballadors = new TreeSet<>(); 

    public boolean add(Treballador tre) {
        return treballadors.add(tre);
    }

    public void isEmpty() {
        treballadors.isEmpty();
    }

    public void mostrarCognomNom() {
        for (Treballador tre : treballadors) {
            System.out.println(tre.toString());
        }
    }

}
