/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercici5;

import java.util.Objects;

/**
 *
 * @author
 */
class Alumne implements Comparable<Alumne> {

    protected String nom;
    protected String dni;
    protected int notaFinal;

    public Alumne(String nom, String dni, int nota) {
        this.nom = nom;
        this.dni = dni;
        this.notaFinal = nota;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public int getNotaFinal() {
        return notaFinal;
    }

    public void setNotaFinal(int edad) {
        this.notaFinal = edad;
    }

    public String dades() {
        return "Alumne: " + " nom: " + nom + ", dni: " + dni + ", notaFinal: " + notaFinal;
    }

    @Override
    public int compareTo(Alumne o) {
 
            return this.dni.compareTo(((Alumne) o).getDni());
    }

//    @Override
//    public boolean equals(Object o) {
//        //System.out.println("Uso equals");
//        if (o instanceof Alumne) {
//            return this.dni.equals(((Alumne) o).getDni());
//        }
//        return false;
//    }
//
//    @Override
//    public int hashCode() {
//        return this.dni.hashCode();
//    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + Objects.hashCode(this.dni);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Alumne other = (Alumne) obj;
        if (!Objects.equals(this.dni, other.dni)) {
            return false;
        }
        return true;
    }
}
