/*
5)  Fes una classe Curs que tingui un conjunt d'alumnes. 
Aquests alumnes a més del nom i dni guardaran la seva nota final de Curs. 
Fes que aquesta classe curs tingui, a més dels mètodes habituals, 
un mètode mostrar que mostri tots els alumnes ordenats per nota i per nom.
 */
package Exercici5;

import java.util.HashSet;
import java.util.TreeSet;

/**
 *
 * @author judit
 */
public class Curs {

//    TreeSet<Alumne> alumnes = new TreeSet();
    HashSet<Alumne> alumnes = new HashSet();

    public boolean afegir(Alumne alu) {
        return alumnes.add(alu);
    }

    
    public boolean esborrar(String dni) {
         Alumne alu = new Alumne ("", dni, 0);
        return alumnes.remove(alu);
    }

    public Alumne cercar (String dni){
        Alumne alu = null; 
        for (Alumne al: alumnes){
            if (al.dni.equals(dni)){
                alu = al;                
            }
        }        
        return alu;
    }
    
    public void isEmpty() {
        alumnes.isEmpty();
    }

    public void mostrar() {
        for (Alumne alu : alumnes) {
            System.out.println(alu.dades());
        }
    }

    public void mostrarOrdenatNatural() {

        TreeSet<Alumne> ts = new TreeSet<>();
        ts.addAll(alumnes);
        for (Alumne alu : ts) {
            System.out.println(alu.dades());
        }
    }
}
