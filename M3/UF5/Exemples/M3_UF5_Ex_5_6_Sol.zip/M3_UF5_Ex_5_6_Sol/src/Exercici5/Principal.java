/*
 * To change this license header, choose License Headers in Project Proaluties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exercici5;

/**
 *
 * @author judit
 */
public class Principal {

    public static void main(String[] args) {

        Curs curs = new Curs();
        Alumne alu1 = new Alumne("Victor", "11111", 7);
        Alumne alu2 = new Alumne("Marc", "22222", 10);
        Alumne alu3 = new Alumne("Victor", "33333", 7);
        Alumne alu4 = new Alumne("Ruben", "44444", 8);
        Alumne alu5 = new Alumne("Judit", "55555", 8);
        Alumne alu6 = new Alumne("Sergio", "66666", 6);
        Alumne alu7 = new Alumne("Jordi", "66666", 9);

        curs.afegir(alu1);
        curs.afegir(alu2);
        curs.afegir(alu3);
        curs.afegir(alu4);
        curs.afegir(alu5);
        curs.afegir(alu6);
        if (!curs.afegir(alu7)) {
            System.out.println(alu7.dni + "No afegit");
        }

        System.out.println("Sense Ordre-------------------");
        curs.mostrar();
        System.out.println("Ordenat Natural-------------------");
        curs.mostrarOrdenatNatural();
        System.out.println("Ordenat Nota Nom-------------------");
        System.out.println("Esborrar");
        Alumne auxAl = curs.cercar("66666");        
        if (auxAl != null) {
            System.out.println(auxAl.dades());
            curs.esborrar("66666");
            System.out.println("66666 Esborrat");
        } else {
            System.out.println("66666 No trobat");
        }

        System.out.println("Ordenat Nota Nom-------------------");
        curs.mostrarOrdenatNatural();

    }
}
