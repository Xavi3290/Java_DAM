package exemples;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.*;

/**
 *
 * @author alfredo
 */
public class A_MySimpleGUI extends JFrame {

    private JPanel panelDeContenido;
    private JLabel etiqueta1;
    private JTextField campoDeTexto;
    private JLabel labResultado;
    private JTextField campoResultado;
    private JButton boton;

    public A_MySimpleGUI() {
        this.setLocation(200, 200);
        this.setSize(400, 200);
        this.setTitle("Finestra tipus JFrame");
        this.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        etiqueta1 = new JLabel("Mensaje");
        labResultado = new JLabel("Resultado:");
        campoDeTexto = new JTextField(20);
        campoResultado = new JTextField(3);
        boton = new JButton("Aceptar");

        panelDeContenido = new JPanel();
        panelDeContenido.add(etiqueta1);
        panelDeContenido.add(campoDeTexto);
        panelDeContenido.add(boton);
        panelDeContenido.add(labResultado);
        panelDeContenido.add(campoResultado);
        this.setContentPane(panelDeContenido);

        this.addMouseListener(new MyClickListener());
        this.boton.addActionListener(new MyActionListener());
        setVisible(true);
    }

    private class MyClickListener extends MouseAdapter {

        @Override
        public void mouseClicked(MouseEvent event) {
            
            String mensaje = "x:" + event.getX() + " y:" + event.getY() + " Boton: " + event.getButton();
            JOptionPane.showMessageDialog(panelDeContenido, mensaje, "Event Ratolí", HEIGHT);

        }
    }

    private class MyActionListener implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            String mensaje = campoDeTexto.getText();
            int seleccion = JOptionPane.showOptionDialog(
                    panelDeContenido,
                    mensaje,
                    "Selector de opciones",
                    JOptionPane.YES_NO_CANCEL_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null, // null para icono por defecto.
                    new Object[]{"Si", "No", "Cancelar"}, // null para YES, NO y CANCEL
                    "Si");
            campoResultado.setText(String.valueOf(seleccion));

        }
    }

    public static void main(String[] args) {
        A_MySimpleGUI gui = new A_MySimpleGUI();
    }

}
