/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex_1_Pila;

import java.util.Objects;

/**
 *
 * @author
 */
class Persona implements Comparable{

    /**
     * nom del treballador
     */
    protected String nom;
    /**
     * dni del treballador
     */
    protected String dni;
    /**
     * adreca del treballador
     */
    protected String adreca;
    protected int edat;

    public Persona(String nom, String dni, String adreca, int edad) {
        this.nom = nom;
        this.dni = dni;
        this.adreca = adreca;
        this.edat = edad;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getAdreca() {
        return adreca;
    }

    public void setAdreca(String adreca) {
        this.adreca = adreca;
    }

    public String mostra() {
        return "Persona{" + "nom=" + nom + ", dni=" + dni + ", adreca=" + adreca + ", edat=" + edat + "}";
    }

    public int getEdat() {
        return edat;
    }

    public void setEdat(int edad) {
        this.edat = edad;
    }
  
    // Important per Set's
    @Override
    public boolean equals(Object o){
       if (o instanceof Persona) {
        return this.dni.equals(((Persona)o).getDni());
       }
       return false;
    }

    // Si equals==true  Ha de retornar el mateix code
    @Override
    public int hashCode(){
        return this.dni.hashCode();
    }

    @Override
    public int compareTo(Object o) {
        if (o instanceof Persona) {
            return this.dni.compareTo(((Persona)o).dni);
        } else {
            return 1;
        }
    }

}
