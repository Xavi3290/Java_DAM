/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex_2_Cua;

import java.util.LinkedList;

/**
 *
 * @author alfredo
 */
public class Cua<T> {

    protected LinkedList<T> elementos;

    public Cua() {
        elementos = new LinkedList();
    }

    public void add(T e) {
        elementos.addLast(e);
    }

    public T get() {
        T ele = null;
        if (!empty()) {
            ele = elementos.removeFirst();
        }
        return ele;
    }

    public boolean empty() {
        return elementos.isEmpty();
    }

}
