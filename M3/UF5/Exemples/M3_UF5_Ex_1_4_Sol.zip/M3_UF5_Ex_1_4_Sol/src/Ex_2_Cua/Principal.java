/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex_2_Cua;

/**
 *
 * @author alfredo
 */
public class Principal {

    public static void main(String[] args) {
        Cua<Integer> p = new Cua<>();
        Integer i = new Integer(9);
        p.add(7);
        p.add(i);
        p.add(12);
        p.add(21);

        while (!p.empty()) {
            System.out.printf("%d\n", p.get());
        }

        Cua<Persona> pers = new Cua<>();
        Persona p1 = new Persona("Manel", "4444", "adr", 23);
        Persona p2 = new Persona("Joan", "1111", "adr", 25);
        Persona p3 = new Persona("Maria", "3333", "adr", 23);
        Persona p4 = new Persona("Manel", "4444", "adr", 18);

        pers.add(p1);
        pers.add(p2);
        pers.add(p3);
        pers.add(p4);

        while (!pers.empty()) {
            System.out.println(pers.get().mostra());
        }

    }
}
