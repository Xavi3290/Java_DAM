/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Z_Ex_2_Cua_Interfaces;

/**
 *
 * @author alfredo
 */
public class Principal {

    public static void main(String[] args) {
        Cua<Integer> p = new Cua<>();
        
        Integer i = new Integer(9);
        p.add(7);
        p.add(i);
        p.add(12);
        p.add(21);

        while (!p.empty()) {
            System.out.printf("%d \n", p.get());
        }
    }
}
