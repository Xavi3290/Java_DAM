/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Z_Ex_2_Cua_Interfaces;

/**
 *
 * @author alfredo
 */
public interface I_cua<T> {
    void add(T e);
    T get();
    boolean empty();
}
