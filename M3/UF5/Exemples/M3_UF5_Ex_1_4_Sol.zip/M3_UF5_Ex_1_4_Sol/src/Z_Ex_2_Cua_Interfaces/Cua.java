/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Z_Ex_2_Cua_Interfaces;

import java.util.LinkedList;

/**
 *
 * @author alfredo
 */
public class Cua<T> implements I_cua<T> {

    protected LinkedList<T> elementos;

    public Cua() {
        elementos = new LinkedList();
    }

    @Override
    public void add(T e) {
        elementos.addLast(e);
    }

    @Override
    public T get() {
        T ele = null;
        if (!empty()) {
            ele = elementos.removeFirst();
        }
        return ele;
    }

    @Override
    public boolean empty() {
        return elementos.isEmpty();
    }

}
