/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex_3_Impresora;

import java.util.ArrayList;

/**
 *
 * @author alfredo
 */
public class Document {

    private String titol;
    private ArrayList<String> linies = new ArrayList();

    public Document(String titol) {
        this.titol = titol;
    }

    public void afegirLin(String lin) {
        this.linies.add(lin);
    }

    public String dades() {
        String str = "";
        str += "Document: " + titol ;
        for (int i = 0; i < linies.size(); i++) {
              str += "\n     " + this.linies.get(i);
        }
        return str;
    }

}
