/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex_3_Impresora;

/**
 *
 * @author judit
 */
public class Principal {

    public static void main(String[] args) {
        Impressora2 imp = new Impressora2();

        Document d1 = new Document("Titol1");
        d1.afegirLin("1.-Linia1");
        d1.afegirLin("1.-Linia2");
        d1.afegirLin("1.-Linia3");
        System.out.println("Afegim doc1");
        imp.afegirDoc(d1);
        
        Document d2 = new Document("Titol2");
        d2.afegirLin("2.-Linia1");
        d2.afegirLin("2.-Linia2");
        System.out.println("Afegim doc2");
        imp.afegirDoc(d2);

        System.out.println("Impressió");
        imp.imprimirDoc();

        Document d3 = new Document("Titol3");
        d3.afegirLin("3.-Linia1");
        d3.afegirLin("3.-Linia2");
        System.out.println("Afegim doc3");
        imp.afegirDoc(d3);

        while (!imp.cuaBuida()) {
            imp.imprimirDoc();
        }

    }
}
