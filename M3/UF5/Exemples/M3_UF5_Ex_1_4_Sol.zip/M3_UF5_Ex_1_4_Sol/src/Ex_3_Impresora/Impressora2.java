/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex_3_Impresora;

import Ex_2_Cua.Cua;

/**
 *
 * @author alfredo
 */
public class Impressora2 extends Cua<Document>{

    public void afegirDoc(Document d) {
        this.add(d);        
    }

    public void imprimirDoc() {
        Document d = this.get();
        System.out.println(d.dades());
    }

    public boolean cuaBuida() {
        return this.empty();
    }
}
