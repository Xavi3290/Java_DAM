/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex_3_Impresora;

import Ex_2_Cua.Cua;

/**
 *
 * @author alfredo
 */
public class Impressora {

    private Cua<Document> cuaImp = new Cua();

    public void afegirDoc(Document d) {
        cuaImp.add(d);
    }

    public void imprimirDoc() {
        Document d = cuaImp.get();
        System.out.println(d.dades());
    }

    public boolean cuaBuida() {
        return cuaImp.empty();
    }
}
