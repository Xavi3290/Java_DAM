/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex_4_Peatge;

/**
 *
 * @author alfredo
 *
 * Suposa que volem crear un programa per simular un peatge d'una autopista.
 * Suposem que tenim 5 "caixes" per pagar el peatge. Un cotxe quan arriba al
 * peatge anirà a aquella caixa que hi ha menys cotxes. Si diferents caixes
 * tenen aquest mínim número de cotxes anirà indistintament a qualsevol
 * d'aquestes. Crea una classe Peatge amb la col·lecció adient per simular
 * aquesta situació. Fes que aquesta classe a parts dels atributs i mètodes
 * habituals tingui un mètode entraCotxe i un altre surtCotxe.
 *
 */
public class Principal {

    public static void main(String[] args) {
        Peatge peatge = new Peatge();
        
        Cotxe c1 = new Cotxe("Coche 1");
        Cotxe c2 = new Cotxe("Coche 2");
        Cotxe c3 = new Cotxe("Coche 3");
        Cotxe c4 = new Cotxe("Coche 4");
        Cotxe c5 = new Cotxe("Coche 5");
        Cotxe c6 = new Cotxe("Coche 6");
        Cotxe c7 = new Cotxe("Coche 7");
        Cotxe c8 = new Cotxe("Coche 8");

        peatge.entraCotxe(c1);
        peatge.entraCotxe(c2);
        peatge.entraCotxe(c3);
        peatge.entraCotxe(c4);
        peatge.entraCotxe(c5);
        peatge.entraCotxe(c6);
        peatge.entraCotxe(c7);
        peatge.entraCotxe(c8);
        peatge.surtCotxe();
        peatge.surtCotxe();
        peatge.surtCotxe();
        peatge.entraCotxe(new Cotxe("Coche 9"));
        peatge.entraCotxe(new Cotxe("Coche 10"));
        peatge.entraCotxe(new Cotxe("Coche 11"));
        peatge.entraCotxe(new Cotxe("Coche 12"));
        peatge.entraCotxe(new Cotxe("Coche 13"));

        while (!peatge.empty()) {
            peatge.surtCotxe();
        }
        peatge.surtCotxe();
    }
}
