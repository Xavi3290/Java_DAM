/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Ex_4_Peatge;

import java.util.ArrayList;

/**
 * * @author alfredo
 */
public class Peatge {

    private ArrayList<Caixa> caixes;

    Peatge() {
        this.caixes = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            Caixa c = new Caixa("Caixa" + (i + 1));
            caixes.add(c);
        }
    }

    public void entraCotxe(Cotxe e) {
        //añadir coche a la cola mas vacia
        int pos = 0;
        int min = caixes.get(0).numCoches();

        for (int i = 1; i < caixes.size(); i++) {
            if (caixes.get(i).numCoches() < min) {
                min = caixes.get(i).numCoches();
                pos = i;
            }
        }
        caixes.get(pos).add(e);
        System.out.println("Ha entrar el coche," + e.show() + " en la caixa "
                + caixes.get(pos).show());
        System.out.println(this.situacioCaixes());

    }

    public Cotxe surtCotxe() {
        Cotxe c = null;
        //quitar coche random si no esta vacia.

        int pos = 0;
        if (!this.empty()) {
            do {
                pos = (int) (Math.random() * this.caixes.size()) + 0;
            } while (caixes.get(pos).empty());
            c = caixes.get(pos).get();
            System.out.println("->>>Ha sortit el coche " + c.show() + " de la caixa " + caixes.get(pos).show());
            System.out.println(this.situacioCaixes());
        } else {
            System.out.println("->>>No n'hi han cotxes");
        }
        return c;
    }

    public boolean empty() {
        boolean buida = true;
        for (int i = 0; i < this.caixes.size(); i++) {
            if (!caixes.get(i).empty()) {
                buida = false;
                break;
            }
        }
        return buida;
    }
    
    private String situacioCaixes(){
        String str="";
        for(Caixa c: caixes){
            str += "("+c.numCoches()+") ";
        }
        return str;
    }
}
