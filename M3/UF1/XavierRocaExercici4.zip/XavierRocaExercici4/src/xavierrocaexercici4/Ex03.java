/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package xavierrocaexercici4;

import java.util.Scanner;

/**
 *
 * @author usuari
 */
public class Ex03 {
    
    public static void main(String[] args) {
        
        Scanner teclat = new Scanner(System.in);
        
        int num = 9;

        while (num >= 0) {
            System.out.printf("%d \n", num);
            num--;
        }
        System.out.println(" ");
        for (num = 9; num >= 0; num--) {
            System.out.printf("%d \n", num);
        }
        
        
    }
    
}
